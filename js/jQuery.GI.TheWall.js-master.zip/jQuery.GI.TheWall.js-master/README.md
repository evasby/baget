jQuery.GI.TheWall.js
=====================

This plugin could be used to create easily an image gallery similar to the google image search

[Demo](http://goldinteractive.github.io/jQuery.GI.TheWall.js/)

[![Build Status](https://travis-ci.org/Goldinteractive/jQuery.GI.TheWall.js.svg?branch=master)](https://travis-ci.org/Goldinteractive/jQuery.GI.TheWall.js)

